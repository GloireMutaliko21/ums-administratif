export { default as Allocation } from './allocations.mdl.js';
export { default as RemunConge } from './conges.mdl.js';
export { default as Deduction } from './deduction.mdl.js';
export { default as Ferie } from './feries.mdl.js';
export { default as HeureSupp } from './heuresupp.mdl.js';
export { default as MaladAccid } from './maladAccid.mdl.js';
export { default as Prime } from './primes.mdl.js';
export { default as Salaire } from './salaire.mdl.js';