export { default as heureSupp } from './heuresupp.routes.js';
export { default as ferie } from './ferie.routes.js';
export { default as conge } from './conge.routes.js';
export { default as prime } from './prime.routes.js';
export { default as maladAccid } from './maladAccid.routes.js';
export { default as deduction } from './deduction.routes.js';
export { default as allocation } from './allocation.routes.js';
export { default as salaire } from './salaire.routes.js';