export const baseUrl = '/ums/api/admin';

export const agentsUrl = '/agents';

export const paieUrl = '/paie';

export const taskUrl = '/task';

export const cassocUrl = '/cassoc';

export const inventaireUrl = '/inventaire';

export const patrimoineUrl = '/patrimoine'